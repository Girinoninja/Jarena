/// Agente TicoTeco é um agente avançado que equilibra coleta de energia e exploração.
/// Ele prioriza a sobrevivência, comunicação eficaz e adaptação dinâmica ao ambiente do Jarena.
/// Ana Carolina Ceni e Ketlin Gonzaga 




package br.uffs.cc.jarena;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;

public class AgenteTicoTeco extends Agente {
    private boolean emPerigo;
    private ArrayList<Point> pontosDeEnergiaConhecidos;
    private HashMap<String, Point> aliadosConhecidos;
    
    // CONSTANTES DE ESTRATÉGIA BASEADAS EM ENERGIA
    private static final int ENERGIA_CACADOR = 800;
    private static final int ENERGIA_EXPLORADOR = 500;
    private static final int ENERGIA_CRITICA = 100;
    private static final int TEMPO_MAXIMO_NO_COGUMELO = 100;

    // LIMIARES DE ENERGIA (% da energia máxima)
    private static final int ENERGIA_MAX = Constants.ENTIDADE_ENERGIA_INICIAL;
    private static final int ENERGIA_FUGA = (int)(ENERGIA_MAX * 0.25);
    private static final int ENERGIA_BUSCA = (int)(ENERGIA_MAX * 0.45);
    private static final int ENERGIA_OK = (int)(ENERGIA_MAX * 0.60);

    // CONTROLE DE COGUMELOS
    private Point cogumeloAtual = null;
    private int tempoNoCogumelo;
    private boolean deveProcurarNovoCogumelo;
    private int energiaAnterior;
    private ArrayList<Point> cogumelosEsgotados;
    private int tempoSemEnergia = 0;
    private final int LIMITE_TEMPO_SEM_ENERGIA = 1; // Aumentado para esperar mais
    private int tempoEsperaAposEsgotar = 0;
    private final int TEMPO_ESPERA_BUSCA_NOVO = 1; // Espera 3 turnos antes de buscar novo

    // LÓGICA INTERNA
    private String meuPapel;
    private int contadorTurnos;
    private Point objetivoAtual;
    private int tempoNoObjetivo;
    private boolean recebeuEnergiaEsteTurno = false;


    public AgenteTicoTeco(Integer x, Integer y, Integer energia) {
        super(x, y, energia);
        setDirecao(geraDirecaoAleatoria());
        this.emPerigo = false;

        // Inicializa estruturas de dados
        this.pontosDeEnergiaConhecidos = new ArrayList<>();
        this.aliadosConhecidos = new HashMap<>();
        this.cogumelosEsgotados = new ArrayList<>();
        
        // Inicializa controle de cogumelos
        this.cogumeloAtual = null;
        this.tempoNoCogumelo = 0;
        this.deveProcurarNovoCogumelo = true;
        
        // Estado inicial
        this.meuPapel = "EXPLORADOR";
        this.contadorTurnos = 0;
        this.energiaAnterior = getEnergia();
    }

    @Override
    public void pensa() {
        contadorTurnos++;
        recebeuEnergiaEsteTurno = false; // Reset no início do turno
        energiaAnterior = getEnergia();
        atualizarPapel();

        if (getEnergia() < ENERGIA_FUGA) {
            if (!emPerigo) {
                emPerigo = true;
                estrategiaFuga();
            }
            return;
        } else {
            emPerigo = false;
        }

        if (tempoEsperaAposEsgotar > 0) {
            tempoEsperaAposEsgotar--;
            
            // Durante a espera, faz movimento mínimo ou fica parado
            if (Math.random() < 0.3) {
                setDirecao(geraDirecaoAleatoria());
            } else {
                para(); // Fica parado economizando energia
            }
            
            enviaMensagem("ESPERANDO:" + tempoEsperaAposEsgotar);
            return; // Não faz mais nada durante a espera
        }


        Point cogumeloProximo = encontrarCogumeloMaisProximo();
if (cogumeloProximo != null && calcularDistancia(cogumeloProximo) < 25) {
    // Encostou no cogumelo: tenta carregar neste turno
    para();
    cogumeloAtual = cogumeloProximo;
    tempoNoCogumelo++;

    // Comunica
    enviaMensagem("COLETANDO:" + cogumeloAtual.x + "," + cogumeloAtual.y);
    enviaMensagem("COGUMELO:" + cogumeloAtual.x + "," + cogumeloAtual.y);

    // >>> NOVO: se no turno anterior já não recebeu energia, sai imediatamente
    if (tempoSemEnergia >= LIMITE_TEMPO_SEM_ENERGIA) {
        // Marca esgotado e abandona
        cogumelosEsgotados.add(cogumeloAtual);
        pontosDeEnergiaConhecidos.remove(cogumeloAtual);
        enviaMensagem("ESGOTADO:" + cogumeloAtual.x + "," + cogumeloAtual.y);

        // Libera e volta a andar (sem esperar)
        Point esgotado = cogumeloAtual;
        cogumeloAtual = null;
        objetivoAtual = null;
        tempoSemEnergia = 0;

        // Dá um passinho pra fora do cogumelo e segue
        nudgeLongeDoPonto(esgotado);
    }

    // Termina o turno aqui (o motor vai aplicar movimento/ficar parado conforme direção)
    ajustaDirecaoSeNaBorda();
    return;
}

        
        if (cogumeloAtual != null) {
            // Verifica se está recebendo energia
            if (getEnergia() <= energiaAnterior) {
                tempoSemEnergia++;
            } else {
                tempoSemEnergia = 0; // Reset se recebeu energia
                recebeuEnergiaEsteTurno = true;
            }

            boolean cogumeloParouDeDarEnergia = tempoSemEnergia >= LIMITE_TEMPO_SEM_ENERGIA;
            boolean deveSair = deveSairDoCogumeloAtual();

            if (cogumeloParouDeDarEnergia || deveSair) {
    if (cogumeloParouDeDarEnergia) {
        cogumelosEsgotados.add(cogumeloAtual);
        pontosDeEnergiaConhecidos.remove(cogumeloAtual);
        enviaMensagem("ESGOTADO:" + cogumeloAtual.x + "," + cogumeloAtual.y);
    }
    Point antigo = cogumeloAtual;
    cogumeloAtual = null;
    objetivoAtual = null;
    deveProcurarNovoCogumelo = true;
    tempoSemEnergia = 0;

    // Não espera: já sai andando
    nudgeLongeDoPonto(antigo);
    ajustaDirecaoSeNaBorda();
    // segue o fluxo sem return (para já recalcular ação no mesmo pensa)
}
        }

       
        if (cogumeloAtual == null && tempoEsperaAposEsgotar == 0) {
            decidirProximaAcaoBaseadaEnergia();
        }

    
        executarEstrategiaAtual();

        if (deveDividir()) {
            divide();
        }
        
        if (deveComunicar()) {
            comunicaStatus();
        }
        
        if (contadorTurnos % 100 == 0) {
            aliadosConhecidos.clear();
        }
    }

    private boolean emBorda() {
    return getX() <= 0 || getY() <= 0
        || getX() >= (Constants.LARGURA_MAPA - 1)
        || getY() >= (Constants.ALTURA_MAPA - 1);
}

    private void decidirProximaAcaoBaseadaEnergia() {
        int energiaAtual = getEnergia();
        
        if (energiaAtual < ENERGIA_BUSCA) {
            // ENERGIA BAIXA: Busca cogumelo conhecido mais próximo
            estrategiaBuscaEnergia();
        } else if (energiaAtual < ENERGIA_OK) {
            // ENERGIA MÉDIA: Balanceia entre coleta e exploração
            estrategiaBalanceada();
        } else {
            // ENERGIA ALTA: Explora ativamente
            estrategiaExploracaoAtiva();
        }
    }

    private void estrategiaBuscaEnergia() {
        // Prioridade: encontrar cogumelo conhecido mais próximo
        Point cogumeloProximo = encontrarCogumeloMaisProximo();
        
        if (cogumeloProximo != null) {
            objetivoAtual = cogumeloProximo;
            moveEmDirecao(objetivoAtual.x, objetivoAtual.y);
            enviaMensagem("BUSCA_ENERGIA:" + objetivoAtual.x + "," + objetivoAtual.y);
        } else {
            // Se não conhece cogumelos, explora áreas de borda
            exploracaoBordas();
        }
    }

    private void estrategiaBalanceada() {
        // 50% chance de ficar em cogumelo conhecido, 50% de explorar
        if (Math.random() < 0.5 && !pontosDeEnergiaConhecidos.isEmpty()) {
            Point melhorCogumelo = encontrarMelhorCogumeloParaFicar(calcularOcupacaoCogumelos());
            if (melhorCogumelo != null) {
                objetivoAtual = melhorCogumelo;
                moveEmDirecao(objetivoAtual.x, objetivoAtual.y);
            } else {
                encontrarCogumeloMaisProximo();
            }
        } else {
            exploracaoBordas();
        }
    }
    private int direcaoQuicada(int dirAtual) {
    // Se está em qualquer borda, tenta inverter eixo prioritário,
    // mantendo um comportamento simples e previsível.
    boolean bordaEsq = getX() <= 0;
    boolean bordaDir = getX() >= (Constants.LARGURA_MAPA - 1);
    boolean bordaCim = getY() <= 0;
    boolean bordaBai = getY() >= (Constants.ALTURA_MAPA - 1);

    // Se bateu horizontalmente, prioriza vertical e vice-versa
    if (bordaEsq)    return DIREITA;
    if (bordaDir)    return ESQUERDA;
    if (bordaCim)    return BAIXO;
    if (bordaBai)    return CIMA;

    // fallback (não deveria chegar aqui)
    return geraDirecaoAleatoria();
}

// Checa borda e ajusta a direção para "quicar"
private void ajustaDirecaoSeNaBorda() {
    if (emBorda() || !podeMoverPara(getDirecao())) {
        setDirecao(direcaoQuicada(getDirecao()));
    }
}

// Quando sair do cogumelo sem energia, dá um "passinho" pra longe
private void nudgeLongeDoPonto(Point p) {
    if (p == null) return;
    int dx = Integer.compare(getX(), p.x);
    int dy = Integer.compare(getY(), p.y);

    // Escolhe eixo predominante para sair
    if (Math.abs(dx) >= Math.abs(dy)) {
        setDirecao(dx >= 0 ? DIREITA : ESQUERDA);
    } else {
        setDirecao(dy >= 0 ? BAIXO : CIMA);
    }
    ajustaDirecaoSeNaBorda();
}


    private void estrategiaExploracaoAtiva() {
        // Energia alta - foca em explorar novas áreas
        if (objetivoAtual == null || calcularDistancia(objetivoAtual) < 20) {
            objetivoAtual = gerarPontoExploracaoBorda();
        }
        moveEmDirecao(objetivoAtual.x, objetivoAtual.y);
        enviaMensagem("EXPLORANDO:" + objetivoAtual.x + "," + objetivoAtual.y);
    }

    private void exploracaoBordas() {
        // Explora preferencialmente as bordas do mapa (onde os cogumelos costumam estar)
        if (objetivoAtual == null || !podeMoverPara(getDirecao()) || Math.random() < 0.3) {
            objetivoAtual = gerarPontoExploracaoBorda();
        }
        moveEmDirecao(objetivoAtual.x, objetivoAtual.y);
    }

    private Point gerarPontoExploracaoBorda() {
        // Gera pontos preferencialmente nas bordas do mapa
        int margem = 40;
        double random = Math.random();
        
        if (random < 0.25) {
            // Borda superior
            return new Point((int)(Math.random() * Constants.LARGURA_MAPA), margem);
        } else if (random < 0.5) {
            // Borda inferior
            return new Point((int)(Math.random() * Constants.LARGURA_MAPA), Constants.ALTURA_MAPA - margem);
        } else if (random < 0.75) {
            // Borda esquerda
            return new Point(margem, (int)(Math.random() * Constants.ALTURA_MAPA));
        } else {
            // Borda direita
            return new Point(Constants.LARGURA_MAPA - margem, (int)(Math.random() * Constants.ALTURA_MAPA));
        }
    }

    private void executarEstrategiaAtual() {
        if (objetivoAtual != null) {
            tempoNoObjetivo++;
            
            // Verifica se chegou ao objetivo
            if (calcularDistancia(objetivoAtual) < 20) {
                objetivoAtual = null;
                tempoNoObjetivo = 0;
                return;
            }
            
            // Verifica se está há muito tempo no mesmo objetivo
            if (tempoNoObjetivo > 50) {
                objetivoAtual = null;
                tempoNoObjetivo = 0;
                return;
            }
            
            // Move em direção ao objetivo
            moveEmDirecao(objetivoAtual.x, objetivoAtual.y);
        } else {
            // Movimento de exploração básica se não tem objetivo
            if (!podeMoverPara(getDirecao()) || Math.random() < 0.2) {
                setDirecao(geraDirecaoAleatoria());
            }
        }
    }

   

    private Point encontrarCogumeloMaisProximo() {
        if (pontosDeEnergiaConhecidos.isEmpty()) {
            return null;
        }
        
        Point maisProximo = null;
        double menorDistancia = Double.MAX_VALUE;
        
        for (Point cogumelo : pontosDeEnergiaConhecidos) {
            if (cogumelosEsgotados.contains(cogumelo)) {
                continue;
            }
            
            double dist = calcularDistancia(cogumelo);
            if (dist < menorDistancia) {
                menorDistancia = dist;
                maisProximo = cogumelo;
            }
        }
        
        return maisProximo;
    }

    private boolean deveSairDoCogumeloAtual() {
        if (tempoNoCogumelo > TEMPO_MAXIMO_NO_COGUMELO) return true;
        if (getEnergia() > 1500) return true; // Energia cheia - vai explorar
        
        int agentesProximos = contarAliadosProximos(cogumeloAtual);
        if (agentesProximos >= 3) return true; // Muito congestionado
        
        return false;
    }

    private void estrategiaFuga() {
        if (getEnergia() < ENERGIA_CRITICA) {
            para();
            enviaMensagem("SOCORRO_PARADO:" + getX() + "," + getY());
            return;
        }
        
        Point refugio = encontrarCogumeloMaisProximo();
        if (refugio != null) {
            objetivoAtual = refugio;
            moveEmDirecao(refugio.x, refugio.y);
        } else {
            // Fuga para bordas (áreas geralmente mais seguras)
            objetivoAtual = gerarPontoExploracaoBorda();
            moveEmDirecao(objetivoAtual.x, objetivoAtual.y);
        }
        enviaMensagem("SOCORRO:" + getX() + "," + getY());
    }

 

    @Override
    public void recebeuMensagem(String msg) {
        String[] partes = msg.split(":");
        if (partes.length < 2) return;
        String comando = partes[0];

        try {
            if (comando.equals("COGUMELO") || comando.equals("COLETANDO")) {
                int x = Integer.parseInt(partes[1].split(",")[0]);
                int y = Integer.parseInt(partes[1].split(",")[1]);
                Point p = new Point(x, y);
                adicionaPontoDeEnergiaConhecido(p);

                // Se está com energia baixa, prioriza este cogumelo
                if (getEnergia() < ENERGIA_BUSCA) {
                    objetivoAtual = p;
                }

            } else if (comando.equals("ESGOTADO")) {
                int x = Integer.parseInt(partes[1].split(",")[0]);
                int y = Integer.parseInt(partes[1].split(",")[1]);
                Point p = new Point(x, y);
                pontosDeEnergiaConhecidos.remove(p);
                cogumelosEsgotados.add(p);
                if (objetivoAtual != null && objetivoAtual.equals(p)) {
                    objetivoAtual = null;
                }

            } else if (comando.equals("POS") && partes.length >= 3) {
                int xAliado = Integer.parseInt(partes[1].split(",")[0]);
                int yAliado = Integer.parseInt(partes[1].split(",")[1]);
                aliadosConhecidos.put(partes[1], new Point(xAliado, yAliado));
            }
        } catch (Exception e) {
            // Ignora mensagens mal formatadas
        }
    }

    @Override
    public void recebeuEnergia() {
        Point local = new Point(getX(), getY());
        adicionaPontoDeEnergiaConhecido(local);
        recebeuEnergiaEsteTurno = true;
        tempoSemEnergia = 0; // Reset do contador de tempo sem energia
    }

    private double calcularDistancia(Point p) {
        return Math.sqrt(Math.pow(p.x - getX(), 2) + Math.pow(p.y - getY(), 2));
    }

    private int contarAliadosProximos(Point ponto) {
        int count = 0;
        for (Point aliado : aliadosConhecidos.values()) {
            if (calcularDistancia(aliado, ponto) < 80) {
                count++;
            }
        }
        return count;
    }

    private double calcularDistancia(Point p1, Point p2) {
        return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
    }

    private Point encontrarCogumeloMaisProximoDe(Point referencePoint) {
        Point maisProximo = null;
        double menorDistancia = Double.MAX_VALUE;
        
        for (Point cogumelo : pontosDeEnergiaConhecidos) {
            if (cogumelosEsgotados.contains(cogumelo)) continue;
            
            double dist = calcularDistancia(referencePoint, cogumelo);
            if (dist < menorDistancia) {
                menorDistancia = dist;
                maisProximo = cogumelo;
            }
        }
        return maisProximo;
    }

    private HashMap<Point, Integer> calcularOcupacaoCogumelos() {
        HashMap<Point, Integer> ocupacao = new HashMap<>();
        pontosDeEnergiaConhecidos.forEach(c -> ocupacao.put(c, 0));
        
        for (Point aliadoPos : aliadosConhecidos.values()) {
            Point cogumeloProximo = encontrarCogumeloMaisProximoDe(aliadoPos);
            if (cogumeloProximo != null && calcularDistancia(aliadoPos, cogumeloProximo) < 60) {
                ocupacao.put(cogumeloProximo, ocupacao.get(cogumeloProximo) + 1);
            }
        }
        return ocupacao;
    }

    private Point encontrarMelhorCogumeloParaFicar(HashMap<Point, Integer> ocupacao) {
        Point melhorCogumelo = null;
        double melhorPontuacao = -1;
        
        for (Point cogumelo : pontosDeEnergiaConhecidos) {
            if (cogumelosEsgotados.contains(cogumelo)) continue;
            
            int agentes = ocupacao.getOrDefault(cogumelo, 0);
            double distancia = calcularDistancia(cogumelo);
            
            double pontuacao = (100.0 / (distancia + 1)) * (1.0 / (agentes + 1));
            
            if (pontuacao > melhorPontuacao) {
                melhorPontuacao = pontuacao;
                melhorCogumelo = cogumelo;
            }
        }
        
        return melhorCogumelo;
    }

    private void adicionaPontoDeEnergiaConhecido(Point novoPonto) {
        if (!pontosDeEnergiaConhecidos.contains(novoPonto)) {
            pontosDeEnergiaConhecidos.add(novoPonto);
        }
    }

    private void atualizarPapel() {
        if (getEnergia() > ENERGIA_CACADOR) meuPapel = "CACADOR";
        else if (getEnergia() > ENERGIA_EXPLORADOR) meuPapel = "EXPLORADOR";
        else meuPapel = "SUPORTE";
    }

    private void comunicaStatus() {
        enviaMensagem("POS:" + getX() + "," + getY() + ":" + meuPapel);
        
        if (Math.random() < 0.1 && !pontosDeEnergiaConhecidos.isEmpty()) {
            Point cogumelo = pontosDeEnergiaConhecidos.get((int)(Math.random() * pontosDeEnergiaConhecidos.size()));
            enviaMensagem("COGUMELO:" + cogumelo.x + "," + cogumelo.y);
        }
    }

    private void moveEmDirecao(int x, int y) {
    int diffX = x - getX();
    int diffY = y - getY();
    if (Math.abs(diffX) > Math.abs(diffY)) {
        setDirecao(diffX > 0 ? DIREITA : ESQUERDA);
    } else {
        setDirecao(diffY > 0 ? BAIXO : CIMA);
    }
    ajustaDirecaoSeNaBorda(); // <<< garante quicar se estiver colando
}

    private boolean deveComunicar() {
        return contadorTurnos % 10 == 0 || getEnergia() < ENERGIA_BUSCA;
    }

    private boolean deveDividir() {
        if (!podeDividir() || getEnergia() < 1200) return false;
        return cogumeloAtual != null && calcularDistancia(cogumeloAtual) < 50;
    }

    @Override
    public void tomouDano(int energiaRestanteInimigo) {
        if (getEnergia() > 900) {
            para();
            enviaMensagem("LUTANDO:" + getX() + "," + getY());
        } else {
            estrategiaFuga();
            enviaMensagem("FUGINDO:" + getX() + "," + getY());
        }
    }

    @Override
    public void ganhouCombate() {
        objetivoAtual = encontrarCogumeloMaisProximo();
    }
    
    @Override
    public String getEquipe() {
        return "AgenteTicoTeco";
    }
}